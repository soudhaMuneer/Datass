﻿namespace HireMeNowWebApi.Models
{
    public class Education
    {
        public Education() { }
        public int Id { get; set; }
        public string Course { get; set; }
        public string Mark { get; set; }
        public string Year { get; set; }
        public string University { get; set; }
    }
}
