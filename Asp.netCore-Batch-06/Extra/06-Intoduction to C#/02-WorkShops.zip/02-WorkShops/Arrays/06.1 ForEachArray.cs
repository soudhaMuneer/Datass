using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace BAsicProgramming
{
     class Management
    {

        static void Main(string[] args)
        {
            int[] numbers = { 4, 5, 6, 1, 2, 3, -2, -1, 0 };
            foreach (int i in numbers)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
    
}
