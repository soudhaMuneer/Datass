import { Component } from '@angular/core';

@Component({
  selector: 'app-main-count1',
  templateUrl: './main-count1.component.html',
  styleUrls: ['./main-count1.component.css']
})
export class MainCount1Component {

}
