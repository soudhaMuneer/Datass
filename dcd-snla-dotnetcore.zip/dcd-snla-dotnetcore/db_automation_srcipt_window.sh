#!/bin/bash
sql_file_list=`ls -A1 /var/opt/mssql/backup/scripts`
echo "file list in variable"
for sql_file in $sql_file_list;
do
	echo ${sql_file}
	/opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P 'xpWv5kL1234' -d scan_and_learn_arabic -i /var/opt/mssql/backup/scripts/${sql_file}
done

