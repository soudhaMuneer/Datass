using Dcd.Snla.Domain.Entities;
using Dcd.Snla.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Dcd.Snla.Data;

public class ApplicationDatabaseContext : DbContext
{
    public ApplicationDatabaseContext(DbContextOptions<ApplicationDatabaseContext> options)
       : base(options)
    {
    }

    public DbSet<Country> Countries { get; set; }
    public DbSet<Setting> Settings { get; set; }
    public DbSet<Word> SNLA_Word { get; set; }
    public DbSet<WordPronunciation> SNLA_WordPronunciation { get; set; }
    public DbSet<ScannedWord> SNLA_Scanned_Word { get; set; }
    public DbSet<PopularWord> SNLA_Popular_Word { get; set; }



    /// <summary>
    /// Entity model definitions
    /// </summary>
    /// <param name="builder"></param>
    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Word>()
        .HasOne(p => p.wordpronunciation)
        .WithOne(b => b.Word)
        .HasForeignKey<WordPronunciation>(p => p.word_id);
        //TODO
        //Seed data here
    }

    /// <summary>
    /// SaveChangesAsync with entities audit
    /// </summary>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken())
    {
        foreach (var entry in ChangeTracker.Entries<AuditableEntity>())
        {
            switch (entry.State)
            {
                case EntityState.Added:
                    entry.Entity.CreatedDate = DateTime.Now;
                    //entry.Entity.CreatedBy = _loggedInUserService.UserId;
                    break;
                case EntityState.Modified:
                    entry.Entity.LastModifiedDate = DateTime.Now;
                    //entry.Entity.LastModifiedBy = _loggedInUserService.UserId;
                    break;
            }
        }
        return base.SaveChangesAsync(cancellationToken);
    }
}