using Dcd.Snla.Application.Interfaces.Repositories.Domain;
using Dcd.Snla.Data.Repositories;
using Dcd.Snla.Domain.Interfaces.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Dcd.Snla.Data;

public static class PersistenceServiceRegistration
{
    public static IServiceCollection AddPersistenceServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddDbContext<ApplicationDatabaseContext>(options =>
        options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));
        services.AddScoped(typeof(IAsyncRepository<>), typeof(BaseRepository<>));

        services.AddScoped<ICountryRepository, CountryRepository>();
        services.AddScoped<ISettingRepository, SettingRepository>();
        services.AddScoped<IScannedWordRepository, ScannedWordRepository>();
        services.AddScoped<IPopularWordRepository, PopularWordRepository>();



        return services;
    }
}