﻿using Dcd.Snla.Application.Interfaces.Repositories.Domain;
using Dcd.Snla.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcd.Snla.Data.Repositories;
public class ScannedWordRepository : BaseRepository<ScannedWord>, IScannedWordRepository
{
    public ScannedWordRepository(ApplicationDatabaseContext dbContext) : base(dbContext)
    {
    }
}
