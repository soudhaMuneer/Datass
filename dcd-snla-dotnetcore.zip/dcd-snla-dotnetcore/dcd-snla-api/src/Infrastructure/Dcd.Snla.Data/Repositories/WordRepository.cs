﻿

using Dcd.Snla.Application.Interfaces.Repositories.Domain;
using Dcd.Snla.Domain.Entities;


namespace Dcd.Snla.Data.Repositories;

public class WordRepository : BaseRepository<Word>, IWordRepository
{
    public WordRepository(ApplicationDatabaseContext dbContext) : base(dbContext)
    {
    }
   
}


