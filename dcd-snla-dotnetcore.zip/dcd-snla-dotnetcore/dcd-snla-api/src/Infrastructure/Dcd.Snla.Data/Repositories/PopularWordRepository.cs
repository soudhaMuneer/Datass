﻿using Dcd.Snla.Application.Interfaces.Repositories.Domain;
using Dcd.Snla.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcd.Snla.Data.Repositories
{
    public class PopularWordRepository : BaseRepository<PopularWord>, IPopularWordRepository
    {
        public PopularWordRepository(ApplicationDatabaseContext dbContext) : base(dbContext)
        {
        }
        public async Task<PopularWord> GetByWordId(Guid wordId)
        {
            var a = await _dbContext.Set<PopularWord>().FirstOrDefaultAsync(s => s.word_id == wordId);
            return a;
        }
    }
}
