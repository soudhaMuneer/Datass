using Dcd.Snla.Application.Interfaces.Repositories.Domain;
using Dcd.Snla.Domain.Entities;

namespace Dcd.Snla.Data.Repositories;

public class CountryRepository : BaseRepository<Country>, ICountryRepository
{
    public CountryRepository(ApplicationDatabaseContext dbContext) : base(dbContext)
    {
    }
}
