﻿

using Dcd.Snla.Application.Interfaces.Repositories.Domain;
using Dcd.Snla.Domain.Entities;

namespace Dcd.Snla.Data.Repositories;

public class WordPronunciationRepository: BaseRepository<WordPronunciation>, IWordPronunciationRepository 
{
    public WordPronunciationRepository(ApplicationDatabaseContext dbContext) : base(dbContext)
    {
    }

    public async Task<WordPronunciation> GetByWordId(Guid word_id)
    {
        var a =  _dbContext.Set<WordPronunciation>().FirstOrDefault(s => s.word_id == word_id);
        return a;
    }
}


