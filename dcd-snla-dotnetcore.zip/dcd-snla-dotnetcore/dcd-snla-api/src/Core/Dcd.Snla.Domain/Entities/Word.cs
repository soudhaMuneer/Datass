﻿
using Dcd.Snla.Domain.Interfaces;

namespace Dcd.Snla.Domain.Entities
{
    public partial class Word : AuditableEntity
    {
        public Guid Id { get; set; }
        public string Name { get; set; }

        public string title_ar { get; set; }
        public string emirati_dilect_ar { get; set; }
        public string interesting_facts_ar { get; set; }
        public string interesting_facts { get; set; }
        public WordPronunciation wordpronunciation { get; set; }
      
    }
}
