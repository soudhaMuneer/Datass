﻿
using Dcd.Snla.Domain.Interfaces;
using System.ComponentModel.DataAnnotations;

namespace Dcd.Snla.Domain.Entities
{
    public partial class WordPronunciation 
    {
        public Guid Id { get; set; }
        [Required]
        public string title { get; set; }

        public string emirati_dialect { get; set; }
        public string interesting_facts { get; set; }
        public string lang_key { get; set; }
        public Word Word { get; set; }
        public Guid word_id { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public int Version { get; set; } = 1;

       
    }

}
