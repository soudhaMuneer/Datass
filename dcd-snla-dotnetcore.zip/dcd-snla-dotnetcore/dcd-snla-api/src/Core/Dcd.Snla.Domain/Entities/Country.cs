namespace Dcd.Snla.Domain.Entities;

public class Country
{
    public Guid Id { get; set; }
    public string Iso { get;  set; }
    public string Name { get;  set; }
    public string Iso3 { get;  set; }
    public int NumCode { get;  set; }
    public int PhoneCode { get;  set; }
    public bool IsActive { get; set; }

    public Country() {}

    private Country(Guid id, string iso, string name, string iso3, int numCode, int phoneCode)
    {
        Id = id;
        Iso = iso;
        Name = name;
        Iso3 = iso3;
        NumCode = numCode;
        PhoneCode = phoneCode;
        IsActive = true;
    }

    public static Country Create(Guid id, string iso, string name, string iso3, int numCode, int phoneCode)
    {
        return new Country(id, iso, name, iso3, numCode, phoneCode);
    }
}
