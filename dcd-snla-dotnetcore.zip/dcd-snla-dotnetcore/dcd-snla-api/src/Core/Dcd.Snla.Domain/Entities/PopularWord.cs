﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcd.Snla.Domain.Entities;
    public class PopularWord
    {
    public Guid id { get; set; }
    public Guid word_id { get; set; }
    public string name { get; set; }
    public string title_ar { get; set; }
    public string emirati_dialect_ar { get; set; }
    public string interesting_facts_ar { get; set; }
    public int learned_count { get; set; }
    public int scanned_count { get; set; }
}
