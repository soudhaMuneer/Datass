﻿using System;

namespace Dcd.Snla.Domain.Entities;
    public class ScannedWord
    {
    public Guid id { get; set; }
    public Guid word_id { get; set; }
    public Guid user_id { get; set; }
    public DateTime scanned_date_time { get; set; }
    public string createdby { get; set; }
    public DateTime createddate { get; set; }
    public string lastmodifiedby { get; set; }
    public DateTime lastmodifieddate { get; set; }
    public int version { get; set; }
    }
