using Dcd.Snla.Domain.Interfaces;

namespace Dcd.Snla.Domain.Entities;

public class Setting : AuditableEntity
{
    public Guid Id { get; set; }
    public string PrivacyPolicy { get; private set; }
    public string TermsAndConditions { get; private set; }
    public string AboutUs { get; private set; }
}
