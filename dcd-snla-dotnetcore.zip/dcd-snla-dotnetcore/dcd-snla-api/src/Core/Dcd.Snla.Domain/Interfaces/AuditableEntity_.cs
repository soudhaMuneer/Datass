namespace Dcd.Snla.Domain.Entities;

public abstract class AuditableEntity_<TId> : IAuditableEntity<TId>
{
    public TId Id { get; set; }
    public string CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public string LastModifiedBy { get; set; }
    public DateTime? LastModifiedDate { get; set; }
    public bool IsActive { get; set; } = true;
    public int Version { get; set; } = 1;
}
