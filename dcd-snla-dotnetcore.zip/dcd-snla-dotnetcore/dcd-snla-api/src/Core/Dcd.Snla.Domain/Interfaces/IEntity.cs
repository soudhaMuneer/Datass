namespace Dcd.Snla.Domain.Entities;

/// <summary>
/// Generic abstraction for a domain entity
/// </summary>
/// <typeparam name="TId"></typeparam>
public interface IEntity<TId> : IEntity
{
    public TId Id { get; set; }
}

public interface IEntity
{
}
