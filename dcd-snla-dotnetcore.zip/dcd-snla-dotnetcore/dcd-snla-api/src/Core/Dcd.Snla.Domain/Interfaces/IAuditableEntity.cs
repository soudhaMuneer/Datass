
namespace Dcd.Snla.Domain.Entities;

public interface IAuditableEntity<TId> : IAuditableEntity, IEntity<TId>
{
}

public interface IAuditableEntity : IEntity
{
    string CreatedBy { get; set; }
    DateTime CreatedDate { get; set; }
    string LastModifiedBy { get; set; }
    DateTime? LastModifiedDate { get; set; }
    bool IsActive { get; set; }
    int Version { get; set; }
}
