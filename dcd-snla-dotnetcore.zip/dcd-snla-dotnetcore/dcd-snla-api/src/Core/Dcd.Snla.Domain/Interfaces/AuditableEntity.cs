namespace Dcd.Snla.Domain.Interfaces;

public abstract class AuditableEntity
{
    public string CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public string LastModifiedBy { get; set; }
    public DateTime? LastModifiedDate { get; set; }
    public bool IsActive { get; set; } = true;
    public int Version { get; set; } = 1;
}
