using AutoMapper;
using Dcd.Snla.Application.Features.Settings.Queries;
using Dcd.Snla.Domain.Entities;

namespace Dcd.Snla.Application.AutoMapper.MappingProfiles;

public class SettingMappingProfile : Profile
{
    public SettingMappingProfile()
    {
        CreateMap<Setting, SettingDto>();
    }
}
