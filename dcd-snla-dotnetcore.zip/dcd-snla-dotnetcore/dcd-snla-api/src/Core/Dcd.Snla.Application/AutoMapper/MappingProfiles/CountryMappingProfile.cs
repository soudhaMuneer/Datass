using AutoMapper;
using Dcd.Snla.Application.Features.Countries.Queries;
using Dcd.Snla.Domain.Entities;

namespace Dcd.Snla.Application.AutoMapper.MappingProfiles;

public class CountryMappingProfile : Profile
{
    public CountryMappingProfile()
    {
        CreateMap<Country, CountryDto>();
    }
}
