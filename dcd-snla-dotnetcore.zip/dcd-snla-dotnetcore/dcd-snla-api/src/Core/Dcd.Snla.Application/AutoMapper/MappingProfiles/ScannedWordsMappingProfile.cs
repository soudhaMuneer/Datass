﻿using AutoMapper;
using Dcd.Snla.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcd.Snla.Application.AutoMapper.MappingProfiles;
    public class ScannedWordsMappingProfile: Profile
{
    public ScannedWordsMappingProfile()
    {
    }
    }
