﻿
using AutoMapper;
using Dcd.Snla.Application.Features.Words.Queries;
using Dcd.Snla.Application.Features.Words.Commands;

using Dcd.Snla.Domain.Entities;

namespace Dcd.Snla.Application.AutoMapper.MappingProfiles;

public class WordMappingProfile : Profile
{
    public WordMappingProfile()
    {
        
       
       
        CreateMap<Word, UpdateWordCommand>().ForMember(dest => dest.interesting_facts_en, opt =>
            opt.MapFrom(src => src.wordpronunciation.interesting_facts))
         .ForMember(dest => dest.emirati_dialect, opt =>
            opt.MapFrom(src => src.wordpronunciation.emirati_dialect));
        CreateMap<Word, WordDto>()
         .ForMember(dest => dest.interesting_facts_en, opt =>
            opt.MapFrom(src => src.wordpronunciation.interesting_facts))
         .ForMember(dest => dest.emirati_dialect, opt =>
            opt.MapFrom(src => src.wordpronunciation.emirati_dialect));

    }
}


