using AutoMapper;
using Dcd.Snla.Application.AutoMapper.MappingProfiles;

namespace Dcd.Snla.Application.AutoMapper;

public class AutoMapperConfig
{
    public static MapperConfiguration RegisterMappings()
    {
        return new MapperConfiguration(config =>
        {
            config.AddProfile<CountryMappingProfile>();
            config.AddProfile<SettingMappingProfile>();
        });
    }
}
