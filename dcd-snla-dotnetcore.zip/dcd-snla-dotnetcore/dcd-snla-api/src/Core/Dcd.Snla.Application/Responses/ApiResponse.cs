namespace Dcd.Snla.Application.Responses;

public abstract class ApiResponse
{
    protected ApiResponse(bool success)
    {
        Success = success;
    }

    public bool Success { get; set; }

    public static ApiSuccessResponse<TData> Ok<TData>(TData data)
    {
        return new ApiSuccessResponse<TData>(data);
    }

    public static ApiErrorResponse Error(string[] errors)
    {
        return new ApiErrorResponse(errors);
    }
}
