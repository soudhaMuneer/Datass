namespace Dcd.Snla.Application.Responses;

public class ApiSuccessResponse<TData> : ApiResponse
{
    public ApiSuccessResponse(TData data) : base(success: true)
    {
        Data = data;
    }

    public TData Data { get; set; }
}
