namespace Dcd.Snla.Application.Responses;

public class ApiErrorResponse : ApiResponse
{
    public ApiErrorResponse(string[] errors) : base(success: false)
    {
        Errors = errors;
    }

    public string[] Errors { get; }
}
