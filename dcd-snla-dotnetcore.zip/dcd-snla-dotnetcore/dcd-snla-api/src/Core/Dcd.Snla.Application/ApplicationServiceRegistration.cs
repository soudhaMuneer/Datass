using System.Reflection;
using MediatR;
using Microsoft.Extensions.DependencyInjection;

namespace Dcd.Snla.Application;

public static class ApplicationServiceRegistration
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        services.AddAutoMapper(Assembly.GetExecutingAssembly());
        services.AddMediatR(Assembly.GetExecutingAssembly());
        // services.AddMediatR(typeof(myAssemblyStuff).GetTypeInfo().Assembly);

        return services;
    }
}