﻿

using Dcd.Snla.Domain.Entities;
using Dcd.Snla.Domain.Interfaces.Repositories;

namespace Dcd.Snla.Application.Interfaces.Repositories.Domain;

public interface IWordRepository : IAsyncRepository<Word>
{
    
}
