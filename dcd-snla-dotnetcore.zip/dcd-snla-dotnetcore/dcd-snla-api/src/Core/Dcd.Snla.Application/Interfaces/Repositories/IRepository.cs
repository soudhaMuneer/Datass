namespace Dcd.Snla.Domain.Interfaces.Repositories;

public interface IRepository
{
    IUnitOfWork UnitOfWork { get; }
}
