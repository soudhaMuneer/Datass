﻿
using Dcd.Snla.Domain.Entities;
using System.ComponentModel.DataAnnotations;

namespace Dcd.Snla.Application.Features.Words.Queries;

    public class WordDto
    {
    public Guid Id { get; set; }
    public string Name { get; set; }

    public string title_ar { get; set; }
    public string emirati_dilect_ar { get; set; }
    public string interesting_facts_ar { get; set; }
    public string interesting_facts { get; set; }
    public string interesting_facts_en { get; set; }
    public string emirati_dialect { get; set; }
   



}


