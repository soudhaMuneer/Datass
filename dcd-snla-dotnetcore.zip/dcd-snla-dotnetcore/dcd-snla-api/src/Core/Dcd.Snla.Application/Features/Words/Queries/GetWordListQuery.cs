﻿using MediatR;
namespace Dcd.Snla.Application.Features.Words.Queries;
public class GetWordListQuery : IRequest<List<WordDto>>
{
}

