﻿using MediatR;
namespace Dcd.Snla.Application.Features.Words.Queries;
public class GetWordByIdQuery : IRequest<WordDto>
{
    public Guid Id { get; set; }
}

