﻿
using AutoMapper;
using Dcd.Snla.Domain.Entities;
using Dcd.Snla.Domain.Interfaces.Repositories;
using MediatR;
namespace Dcd.Snla.Application.Features.Words.Queries;

public class GetWordListQueryHandler : IRequestHandler<GetWordListQuery, List<WordDto>>
{
    private readonly IAsyncRepository<Word> _WordRepository;
    private readonly IAsyncRepository<WordPronunciation> _WordpronunciationRepository;
    private readonly IMapper _mapper;

    public GetWordListQueryHandler(
        IMapper mapper,
        IAsyncRepository<Word> WordRepository,
        IAsyncRepository<WordPronunciation> WordPronunciationRepository)
    {
        _mapper = mapper;
        _WordRepository = WordRepository;
        _WordpronunciationRepository = WordPronunciationRepository;
    }

    public async Task<List<WordDto>> Handle(GetWordListQuery request, CancellationToken cancellationToken)
    {
        var pro=await _WordpronunciationRepository.ListAllAsync();
;        List<Word> Wordlist = (List<Word>)await _WordRepository.ListAllAsync();

      

        if (Wordlist == null)
        {
            //throw new NotFoundException(nameof(Word), request.Id);
        }
        return _mapper.Map < List < WordDto >> (Wordlist);
        
    }
}
