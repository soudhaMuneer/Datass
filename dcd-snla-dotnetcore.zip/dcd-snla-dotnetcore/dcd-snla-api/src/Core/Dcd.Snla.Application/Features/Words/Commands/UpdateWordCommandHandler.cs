﻿
using AutoMapper;
using Dcd.Snla.Domain.Entities;
using Dcd.Snla.Domain.Interfaces.Repositories;
using MediatR;

namespace Dcd.Snla.Application.Features.Words.Commands
{
    public class UpdateWordCommandHandler : IRequestHandler<UpdateWordCommand>

    {
        private readonly IAsyncRepository<Word> _WordRepository;
        private readonly IAsyncRepository<WordPronunciation> _WordpronunciationRepository;
        private readonly IMapper _mapper;


        public UpdateWordCommandHandler(
            IMapper mapper,
            IAsyncRepository<Word> WordRepository,
             IAsyncRepository<WordPronunciation> WordPronunciationRepository)
        {
            _mapper = mapper;
            _WordRepository = WordRepository;
            _WordpronunciationRepository = WordPronunciationRepository;
        }
        public async Task<Unit> Handle(UpdateWordCommand request, CancellationToken cancellationToken)
        {
            await _WordpronunciationRepository.ListAllAsync();
            var WordToUpdate = await _WordRepository.GetByIdAsync(request.Id);

             if (WordToUpdate == null)
             {
                 throw new Exception("Word Not Found");
             }
             WordToUpdate.emirati_dilect_ar=request.emirati_dilect_ar;
            WordToUpdate.interesting_facts_ar=request.interesting_facts_ar;
            WordToUpdate.interesting_facts = request.interesting_facts;
            WordToUpdate.wordpronunciation.interesting_facts = request.interesting_facts_en;
            WordToUpdate.wordpronunciation.emirati_dialect = request.emirati_dialect;

            await _WordRepository.UpdateAsync(WordToUpdate);

            return Unit.Value;
        }
    }
}
