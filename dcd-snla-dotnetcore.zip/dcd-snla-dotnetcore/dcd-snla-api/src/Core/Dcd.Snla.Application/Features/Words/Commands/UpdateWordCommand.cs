﻿
using System;
using System.Text.Json.Serialization;
using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Dcd.Snla.Application.Features.Words.Commands
{
    public class UpdateWordCommand : IRequest
    {
        [JsonIgnore]
        public Guid Id { get; set; }

        public string emirati_dilect_ar { get; set; }
        public string interesting_facts_ar { get; set; }
        public string interesting_facts { get; set; }
        public string interesting_facts_en{ get; set; }
        public string emirati_dialect { get; set; }
    }
}
