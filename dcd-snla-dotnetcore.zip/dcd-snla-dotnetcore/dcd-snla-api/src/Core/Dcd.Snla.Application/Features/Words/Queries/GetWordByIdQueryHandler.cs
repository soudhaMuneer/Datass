﻿ 
using AutoMapper;
using Dcd.Snla.Application.Interfaces.Repositories.Domain;
using Dcd.Snla.Domain.Entities;
using Dcd.Snla.Domain.Interfaces.Repositories;
using MediatR;
namespace Dcd.Snla.Application.Features.Words.Queries;

public class GetWordByIdQueryHandler : IRequestHandler<GetWordByIdQuery, WordDto>
{
    private readonly IAsyncRepository<Word> _wordRepository;
    private readonly IAsyncRepository<WordPronunciation> _WordpronunciationRepository;
    private readonly IMapper _mapper;

  

    public GetWordByIdQueryHandler(
        IMapper mapper,
        IAsyncRepository<Word> WordRepository,
         IAsyncRepository<WordPronunciation> WordPronunciationRepository
      )
    { 
    
        _mapper = mapper;
        _wordRepository = WordRepository;
        _WordpronunciationRepository = WordPronunciationRepository;
      ;
    }

    public async Task<WordDto> Handle(GetWordByIdQuery request, CancellationToken cancellationToken)
    {
    
        await _WordpronunciationRepository.ListAllAsync();
        
        var word = await _wordRepository.GetByIdAsync(request.Id);
        if (word == null)
        {
            //throw new NotFoundException(nameof(setting), request.Id);
        }
        var wordDto = _mapper.Map<WordDto>(word);
        return wordDto;
    }

}