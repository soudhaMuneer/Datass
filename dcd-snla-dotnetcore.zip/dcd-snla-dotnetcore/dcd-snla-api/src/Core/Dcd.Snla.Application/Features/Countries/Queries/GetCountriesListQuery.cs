using MediatR;

namespace Dcd.Snla.Application.Features.Countries.Queries;

public class GetCountriesListQuery : IRequest<List<CountryDto>>
{
}