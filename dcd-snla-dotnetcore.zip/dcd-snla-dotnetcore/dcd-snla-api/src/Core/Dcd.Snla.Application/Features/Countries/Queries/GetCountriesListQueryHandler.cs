using AutoMapper;
using Dcd.Snla.Domain.Entities;
using Dcd.Snla.Domain.Interfaces.Repositories;
using MediatR;

namespace Dcd.Snla.Application.Features.Countries.Queries;

public class GetCountriesListQueryHandler : IRequestHandler<GetCountriesListQuery, List<CountryDto>>
{
    private readonly IAsyncRepository<Country> _countryRepository;
    private readonly IMapper _mapper;

    public GetCountriesListQueryHandler(
       IMapper mapper,
       IAsyncRepository<Country> countryRepository)
    {
        _mapper = mapper;
        _countryRepository = countryRepository;
    }

    public async Task<List<CountryDto>> Handle(GetCountriesListQuery request, CancellationToken cancellationToken)
    {
        List<Country> countries = new List<Country>();
        Country country = Country.Create(Guid.Parse("{B0788D2F-8003-43C1-92A4-EDC76A7C5DDE}"), "AF", "Afghanistan", "AFG", 4, 93);
        countries.Add(country); 
        country = Country.Create(Guid.Parse("{6313179F-7837-473A-A4D5-A5571B43E6A6}"), "AL", "Albania", "ALB", 8, 355);
        countries.Add(country); 
        country = Country.Create(Guid.Parse("{BF3F3002-7E53-441E-8B76-F6280BE284AA}"), "IN", "India", "IND", 356, 91);
        countries.Add(country); 
        country = Country.Create(Guid.Parse("{FE98F549-E790-4E9F-AA16-18C2292A2EE9}"), "AE", "United Arab Emirates", "ARE", 784, 971);
        countries.Add(country); 
        //var countries = (await _countryRepository.ListAllAsync()).OrderBy(x => x.Name);
        return _mapper.Map<List<CountryDto>>(countries);
    }
}
