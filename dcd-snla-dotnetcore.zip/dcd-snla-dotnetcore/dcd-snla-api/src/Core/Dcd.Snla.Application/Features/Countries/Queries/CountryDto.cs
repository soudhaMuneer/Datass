namespace Dcd.Snla.Application.Features.Countries.Queries;

public class CountryDto
{
    public string Iso { get; set; }
    public string Name { get; set; }
    public int PhoneCode { get; set; }
}
