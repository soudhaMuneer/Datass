using MediatR;

namespace Dcd.Snla.Application.Features.Settings.Commands;

public class UpdatePrivacyPolicyCommand : IRequest
{
    public Guid EventId { get; set; }
    public string PrivacyPolicy { get; set; }
}
