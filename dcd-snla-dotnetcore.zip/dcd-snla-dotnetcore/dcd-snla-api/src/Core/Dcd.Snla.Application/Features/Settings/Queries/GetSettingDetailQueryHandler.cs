using AutoMapper;
using Dcd.Snla.Domain.Entities;
using Dcd.Snla.Domain.Interfaces.Repositories;
using MediatR;

namespace Dcd.Snla.Application.Features.Settings.Queries;

public class GetSettingDetailQueryHandler : IRequestHandler<GetSettingDetailQuery, SettingDto>
{
    private readonly IAsyncRepository<Setting> _settingsRepository;
    private readonly IMapper _mapper;

    public GetSettingDetailQueryHandler(
        IMapper mapper,
        IAsyncRepository<Setting> settingsRepository)
    {
        _mapper = mapper;
        _settingsRepository = settingsRepository;
    }

    public async Task<SettingDto> Handle(GetSettingDetailQuery request, CancellationToken cancellationToken)
    {
        var setting = await _settingsRepository.GetByIdAsync(request.Id);
        if (setting == null)
        {
            //throw new NotFoundException(nameof(setting), request.Id);
        }
        var settingDto = _mapper.Map<SettingDto>(setting);
        return settingDto;
    }

}