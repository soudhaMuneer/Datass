using MediatR;

namespace Dcd.Snla.Application.Features.Settings.Queries;

public class GetSettingDetailQuery : IRequest<SettingDto>
{
    public Guid Id { get; set; }
}
