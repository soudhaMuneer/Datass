using AutoMapper;
using Dcd.Snla.Domain.Entities;
using Dcd.Snla.Domain.Interfaces.Repositories;
using MediatR;

namespace Dcd.Snla.Application.Features.Settings.Commands;

public class UpdatePrivacyPolicyCommandHandler : IRequestHandler<UpdatePrivacyPolicyCommand>
{
    private readonly IAsyncRepository<Setting> _settingRepository;
    private readonly IMapper _mapper;

    public UpdatePrivacyPolicyCommandHandler(IMapper mapper, IAsyncRepository<Setting> settingRepository)
    {
        _mapper = mapper;
        _settingRepository = settingRepository;
    }

    public async Task<Unit> Handle(UpdatePrivacyPolicyCommand request, CancellationToken cancellationToken)
    {
        var settingToUpdate = await _settingRepository.GetByIdAsync(request.EventId);

        // if (settingToUpdate == null)
        // {
        //     throw new NotFoundException(nameof(Setting), request.EventId);
        // }

        // var validator = new UpdateEventCommandValidator();
        // var validationResult = await validator.ValidateAsync(request);

        // if (validationResult.Errors.Count > 0)
        //     throw new ValidationException(validationResult);

        // _mapper.Map(request, eventToUpdate, typeof(UpdateEventCommand), typeof(Event));

        // await _eventRepository.UpdateAsync(eventToUpdate);

        return Unit.Value;
    }
}
