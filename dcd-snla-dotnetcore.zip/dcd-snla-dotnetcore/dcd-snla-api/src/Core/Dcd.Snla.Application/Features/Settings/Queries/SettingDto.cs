namespace Dcd.Snla.Application.Features.Settings.Queries;

public class SettingDto
{
    public Guid Id { get; set; }
    public string PrivacyPolicy { get; set; }
    public string TermsAndConditions { get; set; }
    public string AboutUs { get; set; }
}
