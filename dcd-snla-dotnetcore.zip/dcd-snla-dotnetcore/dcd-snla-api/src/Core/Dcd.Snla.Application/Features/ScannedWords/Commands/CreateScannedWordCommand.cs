﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcd.Snla.Application.Features.ScannedWords.Commands;
public class CreateScannedWordCommand: IRequest
{
    public CreateScannedWordDTO Model;

    public CreateScannedWordCommand(CreateScannedWordDTO model)
    {
        this.Model = model;

    }
}
public class CreateScannedWordDTO
{
    public Guid id { get; set; }
    public Guid word_id { get; set; }
    public Guid user_id { get; set; }
    public DateTime scanned_date_time { get; set; }
    public string createdby { get; set; }
    public DateTime createddate { get; set; }
    public string lastmodifiedby { get; set; }
    public DateTime lastmodifieddate { get; set; }
    public int version { get; set; }

}
