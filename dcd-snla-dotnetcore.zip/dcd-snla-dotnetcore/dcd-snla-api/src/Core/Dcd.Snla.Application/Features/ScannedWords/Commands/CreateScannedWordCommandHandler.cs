﻿using AutoMapper;
using Dcd.Snla.Application.Interfaces.Repositories.Domain;
using Dcd.Snla.Domain.Entities;
using Dcd.Snla.Domain.Interfaces.Repositories;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcd.Snla.Application.Features.ScannedWords.Commands;
public class CreateScannedWordCommandHandler : IRequestHandler<CreateScannedWordCommand>
{
    private readonly IScannedWordRepository _scannedWordRepository;
    private readonly IPopularWordRepository repo;
    private readonly IMapper _mapper;
    public CreateScannedWordCommandHandler(IMapper mapper, IScannedWordRepository ScannedWordRepository, IPopularWordRepository _repo)
    {
        _mapper = mapper;
        _scannedWordRepository = ScannedWordRepository;
        repo = _repo;
    }
    public async Task<Unit> Handle(CreateScannedWordCommand request, CancellationToken cancellationToken)
    {
        CreateScannedWordDTO model = request.Model;
        ScannedWord entity = new ScannedWord();
        entity.word_id = model.word_id;
        entity.user_id = model.user_id;
        entity.scanned_date_time = DateTime.Now;
        entity.version = model.version;
        entity.createdby = model.createdby;
        entity.createddate = DateTime.Now;
        entity.lastmodifiedby = model.lastmodifiedby;
        entity.lastmodifieddate = model.lastmodifieddate;

        var result= await _scannedWordRepository.AddAsync(entity);
        var popularWordToUpdate = await repo.GetByWordId(model.word_id);
        if (popularWordToUpdate != null)
        {
            popularWordToUpdate.scanned_count = popularWordToUpdate.scanned_count + 1;
            await repo.UpdateAsync(popularWordToUpdate);
        }
        else
            throw new Exception("word not found in popular word table");
        return Unit.Value;
    }
}
