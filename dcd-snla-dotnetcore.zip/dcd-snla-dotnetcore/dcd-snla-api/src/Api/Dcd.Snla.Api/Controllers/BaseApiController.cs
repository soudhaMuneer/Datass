using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Dcd.Snla.Api.Controllers;

/// <summary>
/// Abstract BaseApi Controller Class
/// </summary>
public abstract class BaseApiController<T> : ControllerBase
{
    private IMediator _mediatorInstance;
    private ILogger<T> _loggerInstance;
    protected IMediator _mediator => _mediatorInstance ??= HttpContext.RequestServices.GetService<IMediator>();
    protected ILogger<T> _log => _loggerInstance ??= HttpContext.RequestServices.GetService<ILogger<T>>();
}