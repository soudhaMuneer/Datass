﻿using Dcd.Snla.Application.Features.ScannedWords.Commands;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dcd.Snla.Api.Controllers.v1
{
    [Route("api/v1/public")]
    [ApiController]
    public class ScannedWordsController : BaseApiController<ScannedWordsController>
    {
        [HttpPost]
        public async Task<ActionResult<List<CreateScannedWordDTO>>> create(CreateScannedWordDTO data)
        {
            _log.LogDebug("REST request create ScannedWord");
            var dtos = await _mediator.Send(new CreateScannedWordCommand(data));
            return Ok(dtos);
        }
    }
}
