﻿

using Dcd.Snla.Application.Features.Words.Queries;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace Dcd.Snla.Api.Controllers.v1;
[Produces("application/json")]
[ApiController]
[Route("api/v1/public/words")]
public class WordPublicController : BaseApiController<WordPublicController>
{

    [HttpGet()]
    [AllowAnonymous]
    public async Task<IActionResult> Get()
    {
        var words = await _mediator.Send(new GetWordListQuery());
        return Ok(words);
    }
    [HttpGet("{id}")]
    [AllowAnonymous]
    public async Task<IActionResult> Get([FromRoute] Guid id, CancellationToken ct)
    {
        var word = await _mediator.Send(new GetWordByIdQuery { Id = id });
        return Ok(word);
    }



}