using Dcd.Snla.Application.Features.Settings.Queries;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Dcd.Snla.Api.Controllers.v1;

[Produces("application/json")]
[ApiController]
[Route("api/v1/settings")]
public class SettingController : BaseApiController<SettingController>
{
    /// <summary>
    /// Get Setting By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>Status 200 Ok</returns>
    [HttpGet("{id}")]
    [AllowAnonymous]
    public async Task<IActionResult> GetById(Guid id)
    {
        var brand = await _mediator.Send(new GetSettingDetailQuery() { Id = id });
        return Ok(brand);
    }
}
