using Dcd.Snla.Application.Features.Countries.Queries;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Dcd.Snla.Api.Controllers.v1;

[Produces("application/json")]
[ApiController]
[Route("api/v1/countries")]
public class CountryController : BaseApiController<CountryController>
{
    /// <summary>
    /// Get All Countries
    /// </summary>
    /// <returns>Status 200 OK</returns>
    [HttpGet]
    [AllowAnonymous]
    public async Task<ActionResult<List<CountryDto>>> GetAllCountries()
    {
        _log.LogDebug("REST request to get Countries");
        var dtos = await _mediator.Send(new GetCountriesListQuery());
        return Ok(dtos);
    }

}
