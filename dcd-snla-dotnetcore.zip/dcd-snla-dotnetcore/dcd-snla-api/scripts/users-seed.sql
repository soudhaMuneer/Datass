CREATE TABLE [dbo].[SNLA_User] (
    [id] [uniqueidentifier] NOT NULL PRIMARY KEY,
   [createdby] [varchar](255) NULL,
	[createddate] [datetime] NULL,
	[lastmodifiedby] [varchar](255) NULL,
	[lastmodifieddate] [datetime] NULL,	
	[isactive] [bit] NULL,
	[version] [int] NULL,
    email character varying(150) NOT NULL unique,
    first_name character varying(100),
    image [varbinary](max) NULL,
    image_mime_type character varying(255),
    az_ad_userid character varying(255),
    lang_key character varying(6),
    last_name character varying(100),
    mobile character varying(50),
    nationality character varying(150),
    reset_date datetime,
    reset_key character varying(20),
    last_accessed_date datetime)

GO
INSERT INTO [dbo].[SNLA_User]
           ([id]
           ,[createdby]
           ,[createddate]
           ,[lastmodifiedby]
           ,[lastmodifieddate]
           ,[isactive]
           ,[version]
           ,[email]
           ,[first_name]
           ,[image]
           ,[image_mime_type]
           ,[az_ad_userid]
           ,[lang_key]
           ,[last_name]
           ,[mobile]
           ,[nationality]
           ,[reset_date]
           ,[reset_key]
           ,[last_accessed_date])
     VALUES
           ('2c88a2ad-8601-4f4a-b220-7fe08ea5f01d'
           ,'system'
           ,SYSDATETIME()
           ,'system'
           ,SYSDATETIME()
           ,1
           ,1
           ,'user@localhost.com'
           ,'Mobile'
           ,NULL
           ,NULL
           ,'22557881-7a85-47fc-a276-f51b702ef4d1'
           ,'en'
           ,'User'
           ,'987456321'
           ,'United Arab Emirates',NULL,NULL,NULL)