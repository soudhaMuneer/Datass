**RUN the start script :-**


- **Windows:**   Open the Power-shell with Administrator Permission then run both commands

## (Set-ExecutionPolicy Unrestricted)

## (choco install dos2unix)

## (start_for_window.ps1)


- **Linux :**         start_for_linux.sh


## (run command (chmod +x start_for_linux.sh) if you are facing permission issue)

**SQL Server:-**
Install Microsoft SQL Server Management Studio to connect the MSSQL Database. 
MSSQL:- it is running on 1443 port and host is localhost
**SQL Credential:-**
	

 - [ **UserName**: sa 	**Password**:- xpWv5kL1234 ] 

**Adminer**:-  you can access the database.


 - [ **URL**:- http://127.0.0.1:5002/ ] 

**Traefik:-**

 - It is for checking the container status Graphically, Container
   internal Ip address, and port address.
   

**URL:-**   - [ http://127.0.0.1:5004/dashboard/#/ ] 


 


**dcd-snla-api:-**  backend api is running.


**URL:-** - [ http://127.0.0.1:5000/swagger/index.html ] 





**dcd-snla-admin-console**:-   Front End.

**URL:-** - [  http://127.0.0.1/ ]



 

**Sonarqube:-** 


 **URL:-** - [ http://127.0.0.1:5001/ ] 


**Postgres:-** 


 **URL:-** - [ http://127.0.0.1:5003/ ] 


**Default details:**

 - [ UserName:- **admin** Password:- **admin**]
 
 
 
 

 - To shutdown container without remove the container data
 

      **docker-compose stop**

 - To shutdown container and remove the container data 
 
 
      **docker-compose down**


