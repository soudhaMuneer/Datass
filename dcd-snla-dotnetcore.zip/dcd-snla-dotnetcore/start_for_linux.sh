#!/bin/bash
echo "starting the container"
docker-compose up --build -d
docker exec dcd-snla-sql-server-db bash -c "mkdir /var/opt/mssql/backup"
chmod +x db_automation_script.sh

docker cp ./dcd-snla-api/scripts/* dcd-snla-sql-server-db:/var/opt/mssql/backup
sleep 10;
docker exec -it dcd-snla-sql-server-db /opt/mssql-tools/bin/sqlcmd -S localhost -U SA -P 'xpWv5kL1234' -Q "CREATE DATABASE scan_and_learn_arabic"
echo "database restoring........"
sleep 2;
#docker exec -it dcd-snla-sql-server-db /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P 'xpWv5kL1234' -d scan_and_learn_arabic -i /var/opt/mssql/backup/countries-seed.sql
docker cp ./db_automation_script.sh dcd-snla-sql-server-db:/var/opt/mssql
docker exec dcd-snla-sql-server-db  bash -c "cd /var/opt/mssql; ./db_automation_script.sh"
sleep 5;


